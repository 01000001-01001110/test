﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuSample
{
    public class Repository
    {
        private static Repository instance = new Repository();
        public static Repository Instance
        {
            get { return instance; }
            set { instance = value; }
        }
        private Repository() { }

        public List<MenuStripItem> MainMenuItems { get; set; } = new List<MenuStripItem>();

        public bool AddMenuItem(MenuStripItem menuItem)
        {
            try
            {
                MainMenuItems.Add(menuItem);
                return true;
            }
            catch { return false; }
        }
    }
}
