﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuSample
{
    public class MenuStripItem
    {
        public string Title { get; set; }
        public string Hyperlink { get; set; }
        public List<MenuStripItem> Items { get; set; } //childs of this MenuItem
        public MenuStripItem(string title, string hyperLink)
        {
            Items = new List<MenuStripItem>();
            Title= title;
            Hyperlink = hyperLink;
        }

        public bool AddSubMenuItem(MenuStripItem menuStripItem)
        {
            try
            {
                Items.Add(menuStripItem);
                return true;
            }
            catch { return false; }
        }
    }
}
