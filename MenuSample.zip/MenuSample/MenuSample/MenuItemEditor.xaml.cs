﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using MessageBox = System.Windows.MessageBox;

namespace MenuSample
{
    /// <summary>
    /// Interaction logic for MenuItemEditor.xaml
    /// </summary>
    public partial class MenuItemEditor : System.Windows.Window
    {
        TreeViewItem selectedTreeViewItem;
        public MenuItemEditor()
        {
            InitializeComponent();
            PrintMenuStripItems(Repository.Instance.MainMenuItems);
            ExpandAllNodes(MenuTreeView.Items);
        }

        public void PrintMenuStripItems(List<MenuStripItem> menuStripItems, TreeViewItem parentItem = null)
        {
            foreach (MenuStripItem menuItem in menuStripItems)
            {
                TreeViewItem newItem = new TreeViewItem();
                newItem.Header = menuItem.Title;
                newItem.Tag = menuItem;               

                if (parentItem == null)
                {
                    MenuTreeView.Items.Add(newItem);
                }
                else
                {
                    parentItem.Items.Add(newItem);
                }

                if (menuItem.Items != null && menuItem.Items.Count > 0)
                {
                    PrintMenuStripItems(menuItem.Items, newItem);
                }
            }
        }

        private bool ValidateInputs()
        {
            if(string.IsNullOrEmpty(TitleTb.Text))
            { MessageBox.Show("Please fill Title."); return false; }
            if (string.IsNullOrEmpty(WebsiteLinkTb.Text))
            { MessageBox.Show("Please fill Website URL."); return false; }
            Uri uriResult;
            bool isValidUrl = Uri.TryCreate(WebsiteLinkTb.Text, UriKind.Absolute, out uriResult)
                             && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
            if(!isValidUrl)
            {
                if(WebsiteLinkTb.Text.Substring(0, 4) != "www.")
                {
                    MessageBox.Show("Website URL isn't valid"); return false;
                }
            }

            return true;
        }
        private void Button_Click(object sender, RoutedEventArgs e) //add
        {
            if (!ValidateInputs())
                return;

            string title = TitleTb.Text;
            string websiteLink = WebsiteLinkTb.Text;

            MenuStripItem menuStripItem = new MenuStripItem(title, websiteLink);
            TreeViewItem newItem = new TreeViewItem();
            newItem.Header = title;
            newItem.Tag = menuStripItem;

            if (selectedTreeViewItem == null) //add to main Menu
            {                
                Repository.Instance.AddMenuItem(menuStripItem);
                MenuTreeView.Items.Add(newItem);
            }
            else //add to children of parent
            {
                MenuStripItem parentItem = (MenuStripItem)selectedTreeViewItem.Tag;
                parentItem.AddSubMenuItem(menuStripItem);
                selectedTreeViewItem.Items.Add(newItem);
                selectedTreeViewItem.ExpandSubtree();
            }

            MessageBox.Show("Successfully added");
        }

        private void MenuTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem selectedTreeViewItem = MenuTreeView.SelectedItem as TreeViewItem;
            if (selectedTreeViewItem != null)
            {
                MenuStripItem menuStripItem = (MenuStripItem)selectedTreeViewItem.Tag;
                CurrectSelectedItem.Content = menuStripItem.Title;
                this.selectedTreeViewItem = selectedTreeViewItem;
            }
            else //clicked to empty space = MainMenu
            {
                CurrectSelectedItem.Content = "Main Menu";
                selectedTreeViewItem = null;
            }
        }

        private void SelectMainMenuBtn_Click(object sender, RoutedEventArgs e)
        {
            CurrectSelectedItem.Content = "Main Menu";
            selectedTreeViewItem = null;
        }

        private void RemoveBtn_Click(object sender, RoutedEventArgs e)
        {
            if(selectedTreeViewItem== null) 
                { MessageBox.Show("You can't delete Main Menu!"); return; }

            MenuStripItem selectedMenuItem = (MenuStripItem)selectedTreeViewItem.Tag;
            TreeViewItem parentMenuTreeItem = (TreeViewItem)selectedTreeViewItem.Parent;
            MenuStripItem parentMenuItem = (MenuStripItem)parentMenuTreeItem.Tag;
            parentMenuItem.Items.Remove(selectedMenuItem);
            parentMenuTreeItem.Items.Remove(selectedTreeViewItem);
        }

        private void ExpandAllNodes(ItemCollection nodes)
        {
            foreach (object obj in nodes)
            {
                TreeViewItem item = obj as TreeViewItem;
                if (item != null)
                {
                    item.ExpandSubtree();
                    ExpandAllNodes(item.Items);
                }
            }
        }
    }
}
