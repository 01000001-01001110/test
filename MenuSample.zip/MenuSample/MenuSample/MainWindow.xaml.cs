﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MenuSample
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        ContextMenuStrip menuStrip = new ContextMenuStrip();
        NotifyIcon notifyIcon = new NotifyIcon();

        public MainWindow()
        {
            InitializeComponent();

            this.Hide();
            notifyIcon.Icon = new System.Drawing.Icon(System.IO.Path.Combine(Environment.CurrentDirectory, "ico.ico"));
            notifyIcon.Visible = true;

            ConfigManager.LoadRepositoryFromConfig();
            LoadMenuItems(Repository.Instance.MainMenuItems);
        }
        /// <summary>
        /// Loads all menus and submenus into UI
        /// </summary>
        /// <param name="menuStripItems"></param>
        private void LoadMenuItems(List<MenuStripItem> menuStripItems)
        {
            menuStrip.Items.Clear();

            PrintMenuStripItems(menuStripItems);

            #region Default Menus

            ToolStripMenuItem fullsteamMenuItem = new ToolStripMenuItem("Fullsteam Links");

            ToolStripMenuItem confluenceItem = new ToolStripMenuItem("Confluence", null, OpenLink);
            confluenceItem.Tag = "https://www.google.com";
            fullsteamMenuItem.DropDownItems.Add(confluenceItem);

            ToolStripMenuItem namecheapItem = new ToolStripMenuItem("Azure", null, OpenLink);
            namecheapItem.Tag = "https://www.namecheap.com";
            fullsteamMenuItem.DropDownItems.Add(namecheapItem);

            ToolStripMenuItem automateanddeployItem = new ToolStripMenuItem("Jenkins", null, OpenLink);
            automateanddeployItem.Tag = "https://automateanddeploy.com";
            fullsteamMenuItem.DropDownItems.Add(automateanddeployItem);

            ToolStripMenuItem teamsItem = new ToolStripMenuItem("Teams", null, OpenApplication);
            teamsItem.Tag = @"C:\Program Files (x86)\Microsoft\Teams\current\Teams.exe";
            fullsteamMenuItem.DropDownItems.Add(teamsItem);

            ToolStripMenuItem outlookItem = new ToolStripMenuItem("Outlook", null, OpenApplication);
            outlookItem.Tag = @"C:\Program Files (x86)\Microsoft Office\root\Office16\OUTLOOK.EXE";
            fullsteamMenuItem.DropDownItems.Add(outlookItem);

            ToolStripMenuItem windowsTerminalItem = new ToolStripMenuItem("Windows Terminal", null, OpenApplication);
            windowsTerminalItem.Tag = @"C:\Users\USERNAME\AppData\Local\Microsoft\WindowsApps\wt.exe";
            fullsteamMenuItem.DropDownItems.Add(windowsTerminalItem);

            ToolStripMenuItem automateanddeployItem = new ToolStripMenuItem("Google", null, OpenLink);
            automateanddeployItem.Tag = "https://automateanddeploy.com";
            fullsteamMenuItem.DropDownItems.Add(automateanddeployItem);

            ToolStripMenuItem SuckitItem = new ToolStripMenuItem("Word Search", null, OpenLink);
            SuckitItem.Tag = "https://facebook.com";
            fullsteamMenuItem.DropDownItems.Add(SuckitItem);


            ToolStripMenuItem platformMenuItem = new ToolStripMenuItem("Platform Engineering");
            
            ToolStripMenuItem googleItem = new ToolStripMenuItem("Google", null, OpenLink);
            googleItem.Tag = "https://www.google.com";
            platformMenuItem.DropDownItems.Add(googleItem);

            ToolStripMenuItem namecheapItem = new ToolStripMenuItem("Namecheap", null, OpenLink);
            namecheapItem.Tag = "https://www.namecheap.com";
            platformMenuItem.DropDownItems.Add(namecheapItem);

            ToolStripMenuItem automateanddeployItem = new ToolStripMenuItem("Google", null, OpenLink);
            automateanddeployItem.Tag = "https://automateanddeploy.com";
            platformMenuItem.DropDownItems.Add(automateanddeployItem);

            ToolStripMenuItem SuckitItem = new ToolStripMenuItem("Google", null, OpenLink);
            SuckitItem.Tag = "https://facebook.com";
            platformMenuItem.DropDownItems.Add(SuckitItem);
            
            ToolStripMenuItem settingsMenuItem = new ToolStripMenuItem("Settings");
            settingsMenuItem.Click += Settings_Click;

            ToolStripMenuItem exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += Exit_Click;

            menuStrip.Items.Add(fullsteamMenuItem);
            menuStrip.Items.Add(platformMenuItem);
            menuStrip.Items.Add("-");
            menuStrip.Items.Add(settingsMenuItem);
            menuStrip.Items.Add(exitMenuItem);

            #endregion

            notifyIcon.ContextMenuStrip = menuStrip;
        }

        private void OpenApplication(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            string path = item?.Tag?.ToString();
            if (!string.IsNullOrEmpty(path))
            {
                try
                {
                    System.Diagnostics.Process.Start(path);
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Failed to start application: " + ex.Message);
                }
            }
        }


        private void OpenLink(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            string url = item?.Tag?.ToString();
            if (!string.IsNullOrEmpty(url))
            {
                System.Diagnostics.Process.Start(url);
            }
        }

        /// <summary>
        /// Recursive method to load all menu options
        /// </summary>
        /// <param name="menuStripItems"></param>
        /// <param name="parentItem"></param>
        public void PrintMenuStripItems(List<MenuStripItem> menuStripItems, ToolStripMenuItem parentItem = null)
        {
            foreach (MenuStripItem menuItem in menuStripItems)
            {
                ToolStripMenuItem customMenuItem = new ToolStripMenuItem(menuItem.Title);
                customMenuItem.Tag = menuItem;
                customMenuItem.Click += CustomMenuItem_Click;

                if (parentItem == null)
                {
                    menuStrip.Items.Add(customMenuItem);
                }
                else //add sub menu
                {
                    parentItem.DropDownItems.Add(customMenuItem);
                }

                if (menuItem.Items != null && menuItem.Items.Count > 0)
                {
                    PrintMenuStripItems(menuItem.Items, customMenuItem);
                }
            }
        }
        private void CustomMenuItem_Click(object sender, EventArgs e)
        {
           ToolStripMenuItem toolStripMenuItem = (ToolStripMenuItem)sender;
           MenuStripItem menuStripItem = (MenuStripItem)toolStripMenuItem.Tag;
            if (menuStripItem.Items.Count > 0)
                return;

            try
            {
                System.Diagnostics.Process.Start(menuStripItem.Hyperlink);
            }
            catch (Exception ex) { System.Windows.MessageBox.Show("Failed to open link: " + ex.Message); }
        }

        private void Settings_Click(object sender, EventArgs e)
        {
            MenuItemEditor menuItemEditor = new MenuItemEditor();
            menuItemEditor.ShowDialog();

            ConfigManager.SaveConfig(Repository.Instance);
            //reload
            LoadMenuItems(Repository.Instance.MainMenuItems);
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
