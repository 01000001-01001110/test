﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MenuSample
{
    public static class ConfigManager
    {
        static string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NotifyIconLinksApp");
        static string filePath = Path.Combine(folderPath, "config.json");
        public static bool SaveConfig(Repository repository)
        {
            try
            {
                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);

                using (StreamWriter file = File.CreateText(filePath))
                {
                    // Use the JsonSerializer to serialize the object to JSON
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, repository);
                }
                return true;
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Failed to save config: " + ex.Message);
                return false;
            }
        }

        public static bool LoadRepositoryFromConfig()
        {         
            try
            {
                if (!File.Exists(filePath))
                    return false;

                string json = File.ReadAllText(filePath);
                Repository repository = JsonConvert.DeserializeObject<Repository>(json);

                Repository.Instance = repository;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to get config: " + ex.Message);
                return false;
            }
        }
    }
}
